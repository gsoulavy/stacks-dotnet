﻿namespace $safeprojectname$.Authentication
{
    public static class OpenApiSecurityDefinitions
    {
        public const string Bearer = "bearer";

        public const string OAuth2 = "oauth2";
    }
}
